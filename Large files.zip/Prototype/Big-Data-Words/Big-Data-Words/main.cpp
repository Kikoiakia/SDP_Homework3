#include <iostream>
#include "Program.h"



int main(int argc, char* argv[]) {
	
	Program program;
	program.Run(argc, argv);
	



	return 0;
}